<?php
######################################################################
# GroupDocs Viewer! - Embed Documents         	          	         #
# Copyright (C) 2012 by GroupDocs 	   	   	   	   	   	   	   		 #
# Homepage   : http://groupdocs.com/apps/viewer						 #
# Author     : Marketplace Team	    	   	   	   	   	   	   	   	 #
# Email      : support@groupdocs.com	   	   	   	   	   	   	     #
# Version    : 1.3                       	   	    	   	   		 #
# License    : http://www.gnu.org/copyleft/gpl.html GNU/GPL          #
######################################################################
 
 // no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport( 'joomla.plugin.plugin' );
class plgContentGrpdocsc extends JPlugin {
    /**
     * Constructor
     *
     * For php4 compatability we must not use the __constructor as a constructor for plugins
     * because func_get_args ( void ) returns a copy of all passed arguments NOT references.
     * This causes problems with cross-referencing necessary for the observer design pattern.
     *
     * @param     object $subject The object to observe
     * @param     array  $config  An array that holds the plugin configuration
     * @since 1.5
     */
    function plgContentGrpdocsc(& $subject, $config)
    {
        parent::__construct($subject, $config);
    }

    function onPrepareContent(&$article, &$params, $limitstart=0)
    {
        if(strpos($article->text,"{groupdocs")===false)
            return true;

        $start = substr($article->text, strpos($article->text, "{groupdocs"));

        if(!$start)
            return true;

        $find = substr($start, 0, 1 + strpos($start, "}"));

        if(empty($find))
            return true;

        preg_match_all('/{groupdocs\s+docid=\S*([0-9a-f]{64})\s+width=([\d]*)\s+height=([\d]+)\.*}/', $article->text, $matches);

        foreach($matches[0] as $key => $value) {
            $replace = '<iframe src="https://apps.groupdocs.com/document-viewer/embed/' . $matches[1][$key] . '" frameborder="0" width="'. $matches[2][$key] .'" height="' . $matches[3][$key] . '"></iframe>';
            $article->text = str_replace($value, $replace, $article->text);
        
        }

        return true;    
    }
}
?>
