<?php
/**
 * @version             $Id: grpdocs-embed.php revision date osypov $
 * @package             Joomla
 * @subpackage  System
 * @copyright   Copyright (C) Group Docs, 2012. All rights reserved.
 * @license     GNU GPL v2.0
 * Joomla! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 * See COPYRIGHT.php for copyright notices and details.
 */
 
 // no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport( 'joomla.plugin.plugin' );
class plgContentGrpdocs extends JPlugin {
    /**
     * Constructor
     *
     * For php4 compatability we must not use the __constructor as a constructor for plugins
     * because func_get_args ( void ) returns a copy of all passed arguments NOT references.
     * This causes problems with cross-referencing necessary for the observer design pattern.
     *
     * @param     object $subject The object to observe
     * @param     array  $config  An array that holds the plugin configuration
     * @since 1.5
     */
    function plgContentGrpdocs(& $subject, $config)
    {
        parent::__construct($subject, $config);
    }

    function onPrepareContent(&$article, &$params, $limitstart=0)
    {
        if(strpos($article->text,"{groupdocs")===false)
            return true;

        $start = substr($article->text, strpos($article->text, "{groupdocs"));

        if(!$start)
            return true;

        $find = substr($start, 0, 1 + strpos($start, "}"));

        if(empty($find))
            return true;

        preg_match('/([0-9a-f]){64}/',  $find, $guids);
        preg_match('/width=([0-9]+)/',  $find, $widths);
        preg_match('/height=([0-9]+)/', $find, $heights);

        $guid   = isset($guids[0])   ? $guids[0]   : '';
        $width  = isset($widths[1])  ? $widths[1]  : 500;
        $height = isset($heights[1]) ? $heights[1] : 600;


        $replace = '<iframe src="https://dev-apps.groupdocs.com/document-viewer/embed/' . $guid . '" frameborder="0" width="'. $width .'" height="' . $height . '"></iframe>';

        $article->text = str_replace($find, $replace, $article->text);
        return true;    
    }
}
?>