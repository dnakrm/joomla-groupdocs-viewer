<?php

$userId = $_GET['u'];
$privateKey = $_GET['p'];

if(!empty($_POST) or !empty($_FILES)) {
    include_once('grpdocsAPIClient.php');
    include_once('grpdocsStorageAPI.php');

    $uploads_dir = dirname(__FILE__);

    $tmp_name = $_FILES["file"]["tmp_name"];
    $name = $_FILES["file"]["name"];
    move_uploaded_file($tmp_name, "$uploads_dir/$name");

    $privateKey = trim($_POST['pkey']); 
	$userId = trim($_POST['uid']); 
	$apiClient = new APIClient($privateKey, "https://dev-api.groupdocs.com/v2.0");

	$api = new StorageAPI($apiClient);
	$result = $api->Upload($userId, $name, "uploaded", "file://$uploads_dir/$name");
	unlink("$uploads_dir/$name");
	
	echo"<script>
  window.parent.jInsertEditorText('{groupdocs docid=". @$result->result->url ." width=500 height=600}', 'text');
  window.parent.document.getElementById('sbox-window').close();
	</script>"; die;
}

?>

<html>
<head>
<script>
function embed() {
  var docid  = document.getElementById('docid').value;
  var width  = parseInt(document.getElementById('width').value);
  var height = parseInt(document.getElementById('height').value);

  window.parent.jInsertEditorText('{groupdocs docid=' + docid +' width=' + width + ' height=' + height + '}', 'text');
  window.parent.document.getElementById('sbox-window').close();
}
</script>
<style>
body, table {
    border: 1px solid #E0E0E0;
    color: #333333;
    font-family: Arial,Helvetica,sans-serif;
    font-size: 12px;
    font-weight: bold;
    margin-bottom: 3px;
    padding: 3px;
    text-align: left;
}
</style>
</head>
<body>
<h2>Group Docs Embedder</h2>
<table>
  <form action='' method='post' enctype='multipart/form-data'>
  <tr><td>
      Client ID
  </td><td>
      <input name='uid' type='text' value='<?php echo $userId; ?>'>
  </td></tr>
  <tr><td>
      Private Key
  </td><td>
      <input name='pkey' type='text' value='<?php echo $privateKey; ?>'>
  </td></tr>
  <tr><td>
      Upload file to Group Docs 
  </td><td>
      <input name='file' type='file'> <input value='Upload & Embed!' type='submit'>
  </td></tr>

  
  <tr><td>
      &nbsp;<br><i>or</i><br>&nbsp;
  </td><td>
      &nbsp;
  </td></tr>
  </form>
  <tr><td>
      Paste Group <br>Docs link
  </td><td>
      <input id='docid' type='text'> <br><input onclick="embed();" value='Embed!' type='button'>
  </td></tr>
  <tr><td>
      &nbsp;
  </td><td>
      &nbsp;
  </td></tr>
  <tr><td>
      Height
  </td><td>
      <input id='height' value='600' size='5' type='text' style='text-align:right'>px
  </td></tr>
  <tr><td>
      Width
  </td><td>
      <input id='width' value='500' size='5' type='text' style='text-align:right'>px
  </td></tr>
  <tr><td>
      &nbsp;
  </td><td>
      
  </td></tr>
</table>
</body>
</html>