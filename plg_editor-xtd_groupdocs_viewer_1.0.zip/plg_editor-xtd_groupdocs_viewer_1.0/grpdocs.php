<?php
/**
 * @version             $Id: grpdocs.php revision date tushev $
 * @package             Joomla
 * @subpackage  System
 * @copyright   Copyright (C) S.A. Tushev, 2010. All rights reserved.
 * @license     GNU GPL v2.0
 * Joomla! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 * See COPYRIGHT.php for copyright notices and details.
 */
 
 // no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport( 'joomla.plugin.plugin' );
class plgButtonGrpdocs extends JPlugin {
    /**
     * Constructor
     *
     * For php4 compatability we must not use the __constructor as a constructor for plugins
     * because func_get_args ( void ) returns a copy of all passed arguments NOT references.
     * This causes problems with cross-referencing necessary for the observer design pattern.
     *
     * @param     object $subject The object to observe
     * @param     array  $config  An array that holds the plugin configuration
     * @since 1.5
     */
    function plgButtonGrpdocs(& $subject, $config)
    {
        parent::__construct($subject, $config);
    }
    function onDisplay($name)
    {
        // load plugin params info
        $plugin =& JPluginHelper::getPlugin('editors-xtd', 'grpdocs');
        $pluginParams = new JParameter( $plugin->params );

        $userId = $pluginParams->get( 'userId', '' );
        $privateKey = $pluginParams->get( 'privateKey', '' );
    
        $css = ".button2-left .grpdocsButton {
                    background: transparent url(../plugins/editors-xtd/grpdocs.gif) no-repeat 100% 0px;
                }";
        $doc = & JFactory::getDocument();
        $doc->addStyleDeclaration($css);

		JHTML::_('behavior.modal');
        
        $button = new JObject();
        $button->set('modal', true);
        $button->set('text', JText::_('Embed Group Docs'));
        $button->set('name', 'grpdocsButton');
        $button->set('link', '../plugins/editors-xtd/grpdocs2.php?u='.$userId.'&p='.$privateKey);
		$button->set('options', "{handler: 'iframe', size: {x: 400, y: 400}}");
        return $button;
    }
}

?>
