<?php
// Set flag that this is a parent file
define( '_JEXEC', 1 );
define( 'DS', DIRECTORY_SEPARATOR );
define('JPATH_BASE', dirname(__FILE__).DS.'..'.DS.'..' );

require_once ( JPATH_BASE .DS.'includes'.DS.'defines.php' );
require_once ( JPATH_BASE .DS.'includes'.DS.'framework.php' );
		
JDEBUG ? $_PROFILER->mark( 'afterLoad' ) : null;

 // CREATE THE APPLICATION
$app = JRequest::getString('app', 'site');

$app = $app == 'site' ? 'site' : ($app == 'administrator' ? 'administrator' : 'site');
$app_path = $app == 'site' ? '../..' : '../../administrator';

$mainframe =& JFactory::getApplication($app);
$doc =& JFactory::getDocument();

/** @var jlanguage $lang */
$lang =& JFactory::getLanguage();
$lang->load('plg_editors-xtd_grpdocsc', realpath(JPATH_BASE.DS.'administrator'));

JHTML::_('behavior.mootools');
jimport( 'joomla.plugin.plugin' ) ;
jimport( 'joomla.plugin.helper' ) ;
$plugin = & JPluginHelper::getPlugin( 'editors-xtd', 'grpdocs' ) ;
$pluginParams = new JParameter( $plugin->params ) ;

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

$userId = $pluginParams->get('userId');
$privateKey = $pluginParams->get('privateKey');

if(isset($_GET['page']) && $_GET['page'] == 'tree') {
	include_once(dirname(__FILE__) . '/tree_viewer/treeviewer.php');
	exit();
}

if(!empty($_POST) or !empty($_FILES)) {
	$file = $_FILES['file'];
	$error_text = true; // Show text or number
	define("UPLOAD_ERR_EMPTY",5);
	if($file['size'] == 0 && $file['error'] == 0){
		$file['error'] = 5;
	}
	$upload_errors = array(
		UPLOAD_ERR_OK        => "No errors.",
		UPLOAD_ERR_INI_SIZE    => "Larger than upload_max_filesize.",
		UPLOAD_ERR_FORM_SIZE    => "Larger than form MAX_FILE_SIZE.",
		UPLOAD_ERR_PARTIAL    => "Partial upload.",
		UPLOAD_ERR_NO_FILE        => "No file.",
		UPLOAD_ERR_NO_TMP_DIR    => "No temporary directory.",
		UPLOAD_ERR_CANT_WRITE    => "Can't write to disk.",
		UPLOAD_ERR_EXTENSION     => "File upload stopped by extension.",
		UPLOAD_ERR_EMPTY        => "File is empty." // add this to avoid an offset
	);
	// error: report what PHP says went wrong
	$err = ($error_text) ? $upload_errors[$file['error']] : $file['error'] ;

	if($file['error'] !== 0) {
		echo "<div class='red'>" . $err . "</div>";
	} else {
		include_once(dirname(__FILE__) . '/tree_viewer/lib/groupdocs-php/api/APIClient.php');
		include_once(dirname(__FILE__) . '/tree_viewer/lib/groupdocs-php/api/StorageAPI.php');

		$tmp_name = $_FILES["file"]["tmp_name"];
		$name = $_FILES["file"]["name"];
	 
		$privateKey = trim($_POST['pkey']); 
		$userId = trim($_POST['uid']); 

		$apiClient = new APIClient($privateKey, "https://api.groupdocs.com/v2.0");

		$api = new StorageAPI($apiClient);
		try{
			$result = $api->Upload($userId, $name, "uploaded", "file://$tmp_name");
		} catch (Exception $e) {
			echo $e->getMessage();
			exit();
		}

		echo"<script>
		  window.parent.jInsertEditorText('{groupdocs docid=". @$result->result->guid ." width=".intval($_POST['width'])." height=".intval($_POST['height'])."}', 'text');
		  window.parent.document.getElementById('sbox-window').close();
		</script>"; die;
	}
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	
	<script type="text/javascript" src="tree_viewer/js/jquery-1.5.min.js"></script>
	<script type="text/javascript" src="tree_viewer/lib/jquery_file_tree/jquery.file_tree.js"></script>
	<script type="text/javascript" src="tree_viewer/js/tree_viewer_page.js"></script>
	
	<link href="tree_viewer/lib/jquery_file_tree/jquery.file_tree.css" type="text/css" rel="stylesheet" />
	
	<link href="grpdocs.css" type="text/css" rel="stylesheet" />
	<script type="text/javascript" src="grpdocs.js"></script>
</head>
<body>
<form action='' method='post' enctype='multipart/form-data'>
<h2>GroupDocs Embedder</h2>

<div>
<table>
<tr>
	<td>Client ID</td>
	<td><input id="userId" name='uid' type='text' value='<?php echo $userId; ?>'></td>
</tr>
<tr>
	<td>Private Key</td>
	<td><input id="privateKey" name='pkey' type='text' value='<?php echo $privateKey; ?>'></td>
</tr>
<tr>
	<td>Height</td>
	<td><input id='height' name='height' value='600' size='5' type='text' style='text-align:right'>px</td>
</tr>
<tr>
	<td>Width</td>
	<td><input id='width' name='width' value='500' size='5' type='text' style='text-align:right'>px</td>
</tr>
</table>
</div>

<div class="section">
<ul class="tabs">
	<li class="current">Browse &amp; Embed</li>
	<li>Upload &amp; Embed</li>
	<li>Embed by ID</li>
</ul>
<div>
<span id="groupdocs_keys_error" style="display:none">WARNING: There is no user id and/or private key
			please enter them on GroupDocs Options page
			or fill marked fields and press <a href="#" onclick='loadFileTree();return false'>reload</a>
</span>
</div>
<div class="box visible">
	<div id="groupdocsBrowser">
		<div id="groupdocsBrowserInner" >
		</div>
	</div>
</div>

<div class="box">

    Upload file to GroupDocs 
    <input name='file' type='file'>
    <br />
    <input value='Upload & Embed!' type='submit'>

</div>

<div class="box">

Paste GUID here
<input id='docid' type='text'> <br>
<input onclick="submit_groupdocs_link();" value='Embed!' type='button'>

</div>
</div><!-- .section -->

	
</form>
</body>
</html>
