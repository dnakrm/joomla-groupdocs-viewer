<?php
/**
 * @version 1.3 - GroupDocs Viewer Pulgin
 * @package plugins
 * @copyright Copyright (C) 2012 GroupDocs. All rights reserved.
 * @license - http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */
 
 // no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport( 'joomla.plugin.plugin' );
class plgContentGrpdocsc extends JPlugin {
    /**
     * Constructor
     *
     * For php4 compatability we must not use the __constructor as a constructor for plugins
     * because func_get_args ( void ) returns a copy of all passed arguments NOT references.
     * This causes problems with cross-referencing necessary for the observer design pattern.
     *
     * @param     object $subject The object to observe
     * @param     array  $config  An array that holds the plugin configuration
     * @since 1.5
     */
    function plgContentGrpdocsc(& $subject, $config)
    {
        parent::__construct($subject, $config);
    }

    function onPrepareContent(&$article, &$params, $limitstart=0)
    {

        if(strpos($article->text,"{GroupDocs")===false)
            return true;

        $start = substr($article->text, strpos($article->text, "{GroupDocs"));

        if(!$start)
            return true;

        $find = substr($start, 0, 1 + strpos($start, "}"));

        if(empty($find))
            return true;
     
        // define the regular expression for the bot
        $regex = '#{GroupDocs(.*?)}#si' ;
        // find all instances of plugin and put in $matches
        preg_match_all( $regex, $article->text, $matches ) ;
        // Number of plugins
        $count = count( $matches[0] ) ;
        
        // plugin only processes if there are any instances of the plugin in the text
        if( $count ) {
            
            $this->plgContentProcessGroupdocsViewer( $article, $matches, $count, $regex, $params ) ;
        }

        return true;    
    }

    function plgContentProcessGroupdocsViewer( &$row, &$matches, $count, $regex, &$botParams ) {
        
        for( $i = 0 ; $i < $count ; $i ++ ) {
            if( @$matches[1][$i] ) {
                $inline_params = $matches[1][$i] ;
                
                // get GUID
                $guid_matches = array() ;
                preg_match( '#docid="(.*?)"#si', $inline_params, $guid_matches ) ;
                if( isset( $guid_matches[1] ) ) {
                    $guid = $guid_matches[1];
                } else{
                    $guid = '';
                }

                // get height
                $height_matches = array() ;
                preg_match( '#height="(.*?)"#si', $inline_params, $height_matches ) ;
                
                if( isset( $height_matches[1] ) ) {
                    $height = $height_matches[1];
                } else{
                    $height = '';
                }
                
                // get width
                $width_matches = array() ;
                preg_match( '#width="(.*?)"#si ', $inline_params, $width_matches ) ;
                if( isset( $width_matches[1] ) ) {
                    $width = $width_matches[1];
                } else{
                    $width = '';
                }
            }   
            $cms_version = '2.5';
            $text = '<iframe ' . 'src="http://apps.groupdocs.com/document-viewer/embed/' . $guid . '?&referer=joomla/' . $cms_version .'" width="' . $width . '" height="' . $height . '"></iframe>';
            $row->text = str_replace( $matches[0][$i], $text, $row->text ) ;
        }
    
    }
}
?>

